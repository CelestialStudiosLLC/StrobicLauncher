<?php

Route::view('/error-400', 'custom_errors.400');
Route::view('/error-401', 'custom_errors.401');
Route::view('/error-403', 'custom_errors.403');
Route::view('/error-404', 'custom_errors.404');
Route::view('/error-500', 'custom_errors.500');
Route::view('/error-503', 'custom_errors.503');
