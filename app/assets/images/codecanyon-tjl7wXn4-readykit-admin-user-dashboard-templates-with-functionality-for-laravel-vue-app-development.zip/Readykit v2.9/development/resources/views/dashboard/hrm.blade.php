@extends('layouts.app')

@section('title', trans('default.hrm_dashboard'))

@section('contents')
    <dashboard-hrm></dashboard-hrm>
@endsection
