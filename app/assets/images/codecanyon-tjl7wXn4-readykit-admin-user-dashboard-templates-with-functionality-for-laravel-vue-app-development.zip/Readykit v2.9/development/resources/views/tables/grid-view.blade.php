@extends('layouts.app')

@section('title', trans('default.grid_view'))

@section('contents')
    <grid-view-table></grid-view-table>
@endsection
