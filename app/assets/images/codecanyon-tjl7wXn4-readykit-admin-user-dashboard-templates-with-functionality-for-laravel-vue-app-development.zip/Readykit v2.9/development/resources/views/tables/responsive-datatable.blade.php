@extends('layouts.app')

@section('title', trans('default.responsive_datatable'))

@section('contents')
    <responsive-datatable></responsive-datatable>
@endsection
