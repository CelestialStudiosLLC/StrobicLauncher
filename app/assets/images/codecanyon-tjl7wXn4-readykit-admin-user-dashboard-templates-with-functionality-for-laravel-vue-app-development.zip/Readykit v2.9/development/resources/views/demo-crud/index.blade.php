@extends('layouts.app')

@section('title', trans('default.functional_datatable'))

@section('contents')
    <app-demo-crud></app-demo-crud>
@endsection
