@extends('layouts.app')

@section('title', trans('default.profile'))

@section('contents')
    <social-network-profile></social-network-profile>
@endsection
