@extends('layouts.app')

@section('title', trans('default.pos_view'))

@section('contents')
    <pos-view></pos-view>
@endsection
