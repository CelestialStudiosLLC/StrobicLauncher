@extends('layouts.app')

@section('title', trans('default.all_notifications'))

@section('contents')
    <all-notification></all-notification>
@endsection

