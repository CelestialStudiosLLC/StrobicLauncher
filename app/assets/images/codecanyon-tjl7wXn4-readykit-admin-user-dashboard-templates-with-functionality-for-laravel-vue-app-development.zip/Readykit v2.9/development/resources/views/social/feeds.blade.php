@extends('layouts.app')

@section('title', trans('default.feeds'))

@section('contents')
    <social-network-feed></social-network-feed>
@endsection
