@extends('layouts.app')

@section('title', trans('default.tabs'))

@section('contents')
    <tabs></tabs>
@endsection
