@extends('layouts.app')

@section('title', trans('default.form_wizard'))

@section('contents')
    <form-wizard></form-wizard>
@endsection
