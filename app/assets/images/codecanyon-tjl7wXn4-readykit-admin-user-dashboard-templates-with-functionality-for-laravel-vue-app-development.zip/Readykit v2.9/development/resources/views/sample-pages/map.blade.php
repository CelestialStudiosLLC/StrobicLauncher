@extends('layouts.app')

@section('title', trans('default.maps'))

@section('contents')
    <map-page></map-page>
@endsection
