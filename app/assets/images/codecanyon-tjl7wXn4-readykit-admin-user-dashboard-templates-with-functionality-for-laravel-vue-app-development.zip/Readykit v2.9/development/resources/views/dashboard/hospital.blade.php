@extends('layouts.app')

@section('title', trans('default.hospital_dashboard'))

@section('contents')
    <dashboard-hospital></dashboard-hospital>
@endsection
