@extends('layouts.app')

@section('title', trans('default.progress_bars'))

@section('contents')
    <!-- <tabs></tabs> -->
	<progress-bars></progress-bars>
@endsection
