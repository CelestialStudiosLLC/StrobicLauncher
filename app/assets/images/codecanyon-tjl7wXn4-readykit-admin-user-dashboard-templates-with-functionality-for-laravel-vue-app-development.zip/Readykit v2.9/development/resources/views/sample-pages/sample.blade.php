@extends('layouts.app')

@section('title', trans('default.sample_page'))

@section('contents')
    <blank-page></blank-page>
@endsection
