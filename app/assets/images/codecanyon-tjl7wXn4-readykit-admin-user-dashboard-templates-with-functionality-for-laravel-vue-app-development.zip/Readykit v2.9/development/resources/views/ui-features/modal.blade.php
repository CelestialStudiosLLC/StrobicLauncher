@extends('layouts.app')

@section('title', trans('default.modals'))

@section('contents')
    <app-modals></app-modals>
@endsection

