@extends('layouts.app')

@section('title', trans('default.charts'))

@section('contents')
    <!-- <tabs></tabs> -->
	<charts></charts>
@endsection

