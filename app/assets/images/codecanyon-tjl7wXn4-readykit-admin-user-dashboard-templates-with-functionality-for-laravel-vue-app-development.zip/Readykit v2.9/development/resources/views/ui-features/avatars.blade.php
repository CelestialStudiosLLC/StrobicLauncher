@extends('layouts.app')

@section('title', trans('default.avatars'))

@section('contents')
    <avatars></avatars>
@endsection
