@extends('layouts.app')

@section('title', trans('default.invoice_view'))

@section('contents')
    <invoice-view></invoice-view>
@endsection
