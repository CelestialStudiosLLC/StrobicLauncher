@extends('layouts.app')

@section('title', trans('default.Badges_and_pills'))

@section('contents')
    <badges></badges>
@endsection
