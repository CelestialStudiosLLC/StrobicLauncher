@extends('layouts.app')

@section('title', trans('default.user_and_roles'))

@section('contents')
    <user-roles></user-roles>
@endsection
