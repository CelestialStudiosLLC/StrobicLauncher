@extends('layouts.app')

@section('title', 'Datatable')

@section('contents')
    <test-table></test-table>
@endsection
