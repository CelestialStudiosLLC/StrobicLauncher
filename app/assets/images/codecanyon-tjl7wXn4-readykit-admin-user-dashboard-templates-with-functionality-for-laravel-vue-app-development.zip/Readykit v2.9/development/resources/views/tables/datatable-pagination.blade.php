@extends('layouts.app')

@section('title', trans('default.pagination_datatable'))

@section('contents')
    <datatable-pagination></datatable-pagination>
@endsection
