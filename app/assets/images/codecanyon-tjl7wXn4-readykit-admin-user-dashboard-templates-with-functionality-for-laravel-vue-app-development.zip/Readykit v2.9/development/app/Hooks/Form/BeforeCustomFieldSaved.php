<?php


namespace App\Hooks\Form;


use App\Helpers\Core\Traits\InstanceCreator;
use App\Hooks\HookContract;

class BeforeCustomFieldSaved extends HookContract
{
    use InstanceCreator;

    public function handle()
    {

    }
}