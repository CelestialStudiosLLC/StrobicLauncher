<?php


namespace App\Filters\App\Message;


class MessageFilter
{

}